"""
Handle the files generation.
"""
