"""
Handle all things related to CLI functionality.
"""
