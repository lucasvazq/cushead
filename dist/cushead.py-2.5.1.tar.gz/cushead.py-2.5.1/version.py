__version__ = '2.5.1'

def get_version():
    return __version__