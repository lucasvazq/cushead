"""
Handle the arguments provided from the console interface.
"""
