__version__ = '2.5.2'

def get_version():
    return __version__