"""
Handle jinja templates, extensions and functions.
"""
