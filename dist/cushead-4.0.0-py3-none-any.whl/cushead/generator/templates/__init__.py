"""
Handle the templates.
"""
