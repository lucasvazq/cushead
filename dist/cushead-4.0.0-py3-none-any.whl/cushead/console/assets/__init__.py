"""
Handle assets files.
"""
